#!/usr/bin/env python3
# Cely Mod Checker — controllo locale + confronto online configurabile
# Python 3.10+; solo librerie standard. Non modifica mai le mod.
from __future__ import annotations
import csv, json, os, re, sys, time, threading, webbrowser
from pathlib import Path
from datetime import datetime
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

APP_NAME = "Cely Mod Checker"
CONFIG_PATH = Path.home() / ".cely_mod_checker.json"
DEFAULT_DB = Path(__file__).with_name("mod_status.csv")
EXTS = {".package", ".ts4script"}

def load_config():
    try:
        return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}

def save_config(cfg):
    CONFIG_PATH.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")

def load_db(path):
    entries=[]
    if not path or not Path(path).exists(): return entries
    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        for row in csv.DictReader(f):
            row={str(k).strip().lower(): (v or "").strip() for k,v in row.items() if k}
            if row.get("pattern") and row.get("status"):
                entries.append(row)
    return sorted(entries, key=lambda r: len(r["pattern"]), reverse=True)

def classify(name, entries):
    low=name.casefold()
    for e in entries:
        if e["pattern"].casefold() in low:
            return e["status"], e.get("source",""), e.get("notes","")
    return "Da verificare", "", "Nessuna corrispondenza nel database."

def scan_folder(folder, entries):
    results=[]
    for p in Path(folder).rglob("*"):
        if p.is_file() and p.suffix.lower() in EXTS:
            try:
                st=p.stat()
                status,source,notes=classify(p.name,entries)
                results.append({"name":p.name,"path":str(p.relative_to(folder)),
                    "type":p.suffix.lower(), "modified":datetime.fromtimestamp(st.st_mtime).strftime("%d/%m/%Y %H:%M"),
                    "size":st.st_size,"status":status,"source":source,"notes":notes})
            except OSError as ex:
                results.append({"name":p.name,"path":str(p),"type":p.suffix.lower(),
                    "modified":"","size":0,"status":"Errore lettura","source":"","notes":str(ex)})
    return sorted(results,key=lambda x:x["path"].casefold())

def fetch_json(url):
    req=Request(url, headers={"User-Agent":"CelyModChecker/1.0 (personal mod compatibility helper)"})
    with urlopen(req, timeout=15) as resp:
        if resp.status != 200: raise RuntimeError(f"Risposta HTTP {resp.status}")
        return json.loads(resp.read().decode("utf-8"))

class App:
    def __init__(self,root):
        self.root=root; self.root.title(APP_NAME); self.root.geometry("1050x680"); self.root.minsize(800,520)
        self.cfg=load_config(); self.results=[]; self.folder=tk.StringVar(value=self.cfg.get("mods_folder",""))
        self.db=tk.StringVar(value=self.cfg.get("database",str(DEFAULT_DB)))
        self.query=tk.StringVar(); self.online_url=tk.StringVar(value=self.cfg.get("online_json_url",""))
        self.status=tk.StringVar(value="Pronta. Scegli la cartella Mods per iniziare.")
        self.build()

    def build(self):
        style=ttk.Style()
        try: style.theme_use("clam")
        except Exception: pass
        top=ttk.Frame(self.root,padding=14); top.pack(fill="x")
        ttk.Label(top,text="🪄 Cely Mod Checker",font=("Segoe UI",19,"bold")).pack(anchor="w")
        ttk.Label(top,text="Inventario, database di controllo e report — i file non vengono mai modificati.",foreground="#625477").pack(anchor="w",pady=(2,12))
        row=ttk.Frame(top); row.pack(fill="x")
        ttk.Entry(row,textvariable=self.folder).pack(side="left",fill="x",expand=True)
        ttk.Button(row,text="Scegli cartella Mods",command=self.choose_folder).pack(side="left",padx=6)
        ttk.Button(row,text="Scansiona",command=self.scan).pack(side="left")
        row2=ttk.Frame(top); row2.pack(fill="x",pady=(8,0))
        ttk.Label(row2,text="Database CSV:").pack(side="left")
        ttk.Entry(row2,textvariable=self.db).pack(side="left",fill="x",expand=True,padx=6)
        ttk.Button(row2,text="Scegli CSV",command=self.choose_db).pack(side="left")
        ttk.Button(row2,text="Modifica database",command=self.edit_db).pack(side="left",padx=6)
        online=ttk.LabelFrame(top,text="Controllo online (facoltativo)",padding=8); online.pack(fill="x",pady=(10,0))
        ttk.Label(online,text="URL di un database JSON affidabile:").grid(row=0,column=0,sticky="w")
        ttk.Entry(online,textvariable=self.online_url).grid(row=0,column=1,sticky="ew",padx=6)
        ttk.Button(online,text="Aggiorna database",command=self.update_online).grid(row=0,column=2)
        ttk.Label(online,text="Non è impostato un servizio ufficiale automatico: inserisci solo un endpoint documentato che restituisca JSON nel formato indicato in LEGGIMI.",foreground="#6b6477",wraplength=850).grid(row=1,column=0,columnspan=3,sticky="w",pady=(5,0))
        online.columnconfigure(1,weight=1)
        controls=ttk.Frame(self.root,padding=(14,0,14,6)); controls.pack(fill="x")
        ttk.Label(controls,text="Filtra risultati:").pack(side="left")
        ent=ttk.Entry(controls,textvariable=self.query); ent.pack(side="left",fill="x",expand=True,padx=8)
        self.query.trace_add("write",lambda *_:self.populate())
        ttk.Button(controls,text="Esporta report CSV",command=self.export).pack(side="left")
        cols=("name","path","type","modified","status")
        self.tree=ttk.Treeview(self.root,columns=cols,show="headings")
        for c,label,width in [("name","File",210),("path","Percorso relativo",330),("type","Tipo",85),("modified","Ultima modifica",135),("status","Stato",150)]:
            self.tree.heading(c,text=label); self.tree.column(c,width=width,anchor="w")
        self.tree.pack(fill="both",expand=True,padx=14,pady=6)
        self.tree.bind("<<TreeviewSelect>>",self.show_details)
        self.detail=tk.Text(self.root,height=4,wrap="word",state="disabled"); self.detail.pack(fill="x",padx=14,pady=(0,8))
        ttk.Label(self.root,textvariable=self.status,relief="sunken",anchor="w").pack(fill="x",side="bottom")
        self.root.protocol("WM_DELETE_WINDOW",self.close)

    def choose_folder(self):
        d=filedialog.askdirectory(title="Scegli la cartella Mods di The Sims 4")
        if d: self.folder.set(d)
    def choose_db(self):
        p=filedialog.askopenfilename(title="Scegli database CSV",filetypes=[("CSV","*.csv"),("Tutti i file","*.*")])
        if p: self.db.set(p)
    def edit_db(self):
        p=Path(self.db.get())
        if not p.exists():
            p.parent.mkdir(parents=True,exist_ok=True); p.write_text("pattern,status,source,notes\\n",encoding="utf-8")
        try: os.startfile(str(p)) if sys.platform=="win32" else webbrowser.open(p.as_uri())
        except Exception: messagebox.showinfo("Database",f"Apri questo file con un foglio di calcolo o un editor:\\n{p}")

    def scan(self):
        folder=self.folder.get().strip()
        if not folder or not Path(folder).is_dir():
            messagebox.showwarning("Cartella necessaria","Scegli una cartella Mods valida."); return
        try: entries=load_db(self.db.get().strip())
        except Exception as ex:
            messagebox.showerror("Database non leggibile",str(ex)); return
        self.results=scan_folder(folder,entries)
        self.cfg.update({"mods_folder":folder,"database":self.db.get().strip(),"online_json_url":self.online_url.get().strip()})
        try: save_config(self.cfg)
        except Exception: pass
        self.populate()
        self.status.set(f"Scansione completata: {len(self.results)} file. 'Da verificare' non significa necessariamente obsoleto.")
    def populate(self):
        if not hasattr(self,"tree"): return
        self.tree.delete(*self.tree.get_children())
        q=self.query.get().casefold()
        for i,r in enumerate(self.results):
            if q and q not in (r["name"]+" "+r["path"]+" "+r["status"]).casefold(): continue
            self.tree.insert("","end",iid=str(i),values=(r["name"],r["path"],r["type"],r["modified"],r["status"]))
    def show_details(self,_=None):
        sel=self.tree.selection()
        if not sel:return
        r=self.results[int(sel[0])]
        txt=f"Stato: {r['status']}\\nFonte: {r['source'] or 'nessuna'}\\nNote: {r['notes'] or 'nessuna'}\\nDimensione: {r['size']} byte"
        self.detail.configure(state="normal"); self.detail.delete("1.0","end"); self.detail.insert("1.0",txt); self.detail.configure(state="disabled")
    def export(self):
        if not self.results:
            messagebox.showinfo("Nessun risultato","Prima esegui una scansione."); return
        p=filedialog.asksaveasfilename(title="Salva report",defaultextension=".csv",initialfile="cely_mod_report.csv",filetypes=[("CSV","*.csv")])
        if not p:return
        fields=["name","path","type","modified","size","status","source","notes"]
        try:
            with open(p,"w",encoding="utf-8-sig",newline="") as f:
                w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(self.results)
            self.status.set(f"Report salvato: {p}")
        except Exception as ex: messagebox.showerror("Errore export",str(ex))
    def update_online(self):
        url=self.online_url.get().strip()
        if not url.startswith("https://"):
            messagebox.showwarning("URL non valido","Per sicurezza inserisci un URL HTTPS di un database JSON affidabile."); return
        self.status.set("Controllo online in corso…")
        threading.Thread(target=self._online_worker,args=(url,),daemon=True).start()
    def _online_worker(self,url):
        try:
            data=fetch_json(url)
            # Formato previsto: {"mods":[{"pattern":"nome","status":"Aggiornata","source":"https://...","notes":"..."}]}
            mods=data.get("mods") if isinstance(data,dict) else None
            if not isinstance(mods,list): raise ValueError("JSON non valido: deve contenere una lista 'mods'.")
            clean=[]
            for item in mods:
                if isinstance(item,dict) and item.get("pattern") and item.get("status"):
                    clean.append({k:str(item.get(k,"")) for k in ("pattern","status","source","notes")})
            if not clean: raise ValueError("Il database online non contiene voci riconoscibili.")
            dest=Path(self.db.get().strip() or str(DEFAULT_DB))
            with open(dest,"w",encoding="utf-8-sig",newline="") as f:
                w=csv.DictWriter(f,fieldnames=["pattern","status","source","notes"]);w.writeheader();w.writerows(clean)
            self.root.after(0,lambda:self._online_done(len(clean),str(dest)))
        except Exception as ex:
            self.root.after(0,lambda e=str(ex):self._online_error(e))
    def _online_done(self,n,p):
        self.status.set(f"Database aggiornato con {n} voci: {p}")
        messagebox.showinfo("Aggiornamento completato",f"Importate {n} voci. Esegui di nuovo la scansione per applicarle.")
    def _online_error(self,e):
        self.status.set("Aggiornamento online non riuscito.")
        messagebox.showerror("Errore aggiornamento",f"Non è stato possibile aggiornare il database.\\n{e}\\n\\nPuoi continuare a usare il controllo locale.")
    def close(self):
        self.cfg.update({"mods_folder":self.folder.get(),"database":self.db.get(),"online_json_url":self.online_url.get()})
        try: save_config(self.cfg)
        except Exception: pass
        self.root.destroy()

if __name__=="__main__":
    root=tk.Tk()
    App(root)
    root.mainloop()
